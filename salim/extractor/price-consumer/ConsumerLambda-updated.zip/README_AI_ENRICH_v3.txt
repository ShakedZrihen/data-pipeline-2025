Patched handler: consumer_lambda.py
